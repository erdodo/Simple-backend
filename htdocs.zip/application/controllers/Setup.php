<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Setup extends CI_Controller
{

    public function index()
    {

        $this->load->view('setup');
    }
    public function create()
    {
        $data = (object) $_GET;
        //print_r($data);
        //$this->load->dbforge();

        // Veritabanı oluşturuldu
        //if ($this->dbforge->create_database('simple_database')) echo 'DB Create success';



        $text = " <?php  defined('BASEPATH') or exit('No direct script access allowed'); \n";
        $text = $text . '$' . "active_group = 'default'; \n";
        $text = $text . '$' . "query_builder = TRUE; \n";
        $text = $text . '$' . "db['default'] = ";
        $text = $text . "
        array(
            'dsn'    => '',
            'hostname' => '" . $data->db_host . "',
            'username' => '" . $data->db_user . "',
            'password' => '" . $data->db_pass . "',
            'database' => 'simple_database',
            'dbdriver' => 'mysqli',
            'dbprefix' => '',
            'pconnect' => FALSE,
            'db_debug' => FALSE,
            'cache_on' => FALSE,
            'cachedir' => '',
            'char_set' => 'utf8',
            'dbcollat' => 'utf8_general_ci',
            'swap_pre' => '',
            'encrypt' => FALSE,
            'compress' => FALSE,
            'stricton' => FALSE,
            'failover' => array(),
            'save_queries' => TRUE
        );
        ";

        $file_name = dirname(__FILE__) . "\..\config\database.php";
        $myfile = fopen($file_name, "w");
        echo fwrite($myfile, $text);
        fclose($myfile);
    }
}
